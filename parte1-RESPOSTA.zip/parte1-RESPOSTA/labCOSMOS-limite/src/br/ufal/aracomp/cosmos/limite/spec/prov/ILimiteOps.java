package br.ufal.aracomp.cosmos.limite.spec.prov;

import br.ufal.aracomp.cosmos.limite.spec.dt.ClienteDT;

public interface ILimiteOps {
	public double calcularLimite(ClienteDT client);
}
