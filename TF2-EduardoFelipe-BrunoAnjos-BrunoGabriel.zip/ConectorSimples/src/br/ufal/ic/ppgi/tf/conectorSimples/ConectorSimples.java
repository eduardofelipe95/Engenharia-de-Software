package br.ufal.ic.ppgi.tf.conectorSimples;

import br.ufal.aracomp.cosmos.emprestimo.spec.dt.UsuarioDT;
import br.ufal.aracomp.cosmos.emprestimo.spec.req.ILimiteReq;
import br.ufal.aracomp.cosmos.limite.spec.dt.ClienteDT;
import br.ufal.aracomp.cosmos.limite.spec.prov.ILimiteOps;
import br.ufal.aracomp.cosmos.limite2.spec.dt.ClienteDT2;
import br.ufal.aracomp.cosmos.limite2.spec.prov.ILimiteOps2;

public class ConectorSimples implements ILimiteReq{
	private ILimiteOps limite;
	private ILimiteOps2 limite2;
	
	public ConectorSimples(ILimiteOps limite, ILimiteOps2 limite2) {
		this.limite = limite;
		this.limite2 = limite2;
	}
	
	@Override
	public double estimarLimite(UsuarioDT usuario) {
		ClienteDT cliente = new ClienteDT();
		ClienteDT2 cliente2 = new ClienteDT2();
		
		cliente.salario = Double.parseDouble(usuario.rendimentos);
		cliente2.salario = Double.parseDouble(usuario.rendimentos);
		
		double auxLimite1 = this.limite.calcularLimite(cliente);
		double auxLimite2 =  this.limite2.calcularLimite(cliente2);
		
		//System.out.println(auxLimite1);
		//System.out.println(auxLimite2);
		
		if(auxLimite2 <= auxLimite1*1.05 && auxLimite2 >= auxLimite1*0.95) {
			return (auxLimite1 + auxLimite2)/2;
		}else {
			throw new RuntimeException();
		}
		
		
	}

}
