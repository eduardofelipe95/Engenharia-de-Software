package br.ufal.aracomp.cosmos.emprestimo.spec.dt;

public class UsuarioDT {
	public String rendimentos;
	//TODO complete information
}
