package br.ufal.aracomp.cosmos.limite.spec.dt;

public class ClienteDT {
	public double salario;
	//TODO complete information
}
