package br.ufal.ic.ppgi.tf.conectorSimples;

import java.util.Arrays;

import br.ufal.aracomp.cosmos.emprestimo.spec.dt.UsuarioDT;
import br.ufal.aracomp.cosmos.emprestimo.spec.req.ILimiteReq;
import br.ufal.aracomp.cosmos.limite.spec.dt.ClienteDT;
import br.ufal.aracomp.cosmos.limite.spec.prov.ILimiteOps;
import br.ufal.aracomp.cosmos.limite2.spec.dt.ClienteDT2;
import br.ufal.aracomp.cosmos.limite2.spec.prov.ILimiteOps2;
import br.ufal.aracomp.cosmos.limite3.spec.dt.ClienteDT3;
import br.ufal.aracomp.cosmos.limite3.spec.prov.ILimiteOps3;

public class ConectorSimples implements ILimiteReq{
	private ILimiteOps limite;
	private ILimiteOps2 limite2;
	private ILimiteOps3 limite3;
	
	public ConectorSimples(ILimiteOps limite, ILimiteOps2 limite2, ILimiteOps3 limite3) {
		this.limite = limite;
		this.limite2 = limite2;
		this.limite3 = limite3;
	}
	
	@Override
	public double estimarLimite(UsuarioDT usuario) {
		ClienteDT cliente = new ClienteDT();
		ClienteDT2 cliente2 = new ClienteDT2();
		ClienteDT3 cliente3 = new ClienteDT3();
		
		cliente.salario = Double.parseDouble(usuario.rendimentos);
		cliente2.salario = Double.parseDouble(usuario.rendimentos);
		cliente3.salario = Double.parseDouble(usuario.rendimentos);
		
		double[] limites = new double[3];
		
		limites[0] = this.limite.calcularLimite(cliente);
		limites[1] =  this.limite2.calcularLimite(cliente2);
		limites[2] =  this.limite3.calcularLimite(cliente3);
		
		Arrays.sort(limites);
		
		double centralValue, higherValue,lowerValue;
		
		higherValue = limites[2];
		centralValue = limites[1];
		lowerValue = limites[0];
		
		System.out.println(higherValue);
		System.out.println(centralValue);
		System.out.println(lowerValue);
		
		if(lowerValue >= centralValue*0.95){
			if(lowerValue >= higherValue*0.95) {
				return (higherValue + centralValue + lowerValue)/3;
			}else {
				return (lowerValue + centralValue)/2;
			}
			
		}else if(centralValue >= higherValue*0.95){
			return (centralValue + higherValue)/2;
		}else {
			throw new RuntimeException();
		}
		
		
	}

}
