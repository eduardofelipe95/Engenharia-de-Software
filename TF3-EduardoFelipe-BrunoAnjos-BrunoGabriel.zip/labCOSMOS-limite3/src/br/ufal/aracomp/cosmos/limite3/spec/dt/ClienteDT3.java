package br.ufal.aracomp.cosmos.limite3.spec.dt;

public class ClienteDT3 {
	public double salario;
	//TODO complete information
}
