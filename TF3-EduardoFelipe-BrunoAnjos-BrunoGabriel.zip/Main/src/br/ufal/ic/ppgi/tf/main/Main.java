package br.ufal.ic.ppgi.tf.main;

import br.ufal.aracomp.cosmos.emprestimo.impl.ComponentFactory;
import br.ufal.aracomp.cosmos.emprestimo.spec.dt.UsuarioDT;
import br.ufal.aracomp.cosmos.emprestimo.spec.prov.IEmprestimoOps;
import br.ufal.aracomp.cosmos.emprestimo.spec.prov.IManager;
import br.ufal.aracomp.cosmos.limite.spec.prov.ILimiteOps;
import br.ufal.ic.ppgi.tf.conectorSimples.ConectorSimples;
import br.ufal.aracomp.cosmos.limite2.spec.prov.ILimiteOps2;
import br.ufal.aracomp.cosmos.limite3.spec.prov.ILimiteOps3;


public class Main {
	public static void main(String[] args) {
		IManager emprestimo;
		br.ufal.aracomp.cosmos.limite.spec.prov.IManager limite;
		br.ufal.aracomp.cosmos.limite2.spec.prov.IManager limite2;
		br.ufal.aracomp.cosmos.limite3.spec.prov.IManager limite3;
		
		
		emprestimo = ComponentFactory.createInstance();
		limite = br.ufal.aracomp.cosmos.limite.impl.ComponentFactory.createInstance();
		limite2 = br.ufal.aracomp.cosmos.limite2.impl.ComponentFactory.createInstance();
		limite3 = br.ufal.aracomp.cosmos.limite3.impl.ComponentFactory.createInstance();
		
		ILimiteOps limiteOps = (ILimiteOps)limite.getProvidedInterface("ILimiteOps");
		ILimiteOps2 limiteOps2 = (ILimiteOps2)limite2.getProvidedInterface("ILimiteOps2");
		ILimiteOps3 limiteOps3 = (ILimiteOps3)limite3.getProvidedInterface("ILimiteOps3");
		
		ConectorSimples conn = new ConectorSimples(limiteOps,limiteOps2, limiteOps3);
		emprestimo.setRequiredInterface("ILimiteReq", conn);
		//EXECUCAO
		IEmprestimoOps emprestimoOps = (IEmprestimoOps)emprestimo.getProvidedInterface("IEmprestimoOps");
		
		UsuarioDT usuario = new UsuarioDT();
		usuario.rendimentos="1001";
		
		try {
		
		System.out.println("VALOR DO EMPRESTIMO: " + emprestimoOps.liberarEmprestimoAutomatico(usuario));
		}catch(RuntimeException e){
			System.out.println("Operação não disponível, procure seu gerente para mais informações.");
		}
		
	}
}
